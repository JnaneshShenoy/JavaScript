function isJsonObject(value) {
   return typeof value === 'object' && value !== null;
}

console.log(isJsonObject({1:'Hello',2:"Bye"}));
console.log(isJsonObject(''));
console.log(isJsonObject(null));