function areSame(a, b) {
  return a === b;
}

console.log(areSame(1, "1"));
console.log(areSame(45, 45));
