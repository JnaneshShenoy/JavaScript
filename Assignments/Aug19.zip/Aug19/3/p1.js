function isNumber(value) {
   return typeof value === 'number';
}

console.log(isNumber(3));
console.log(isNumber('Hello'));